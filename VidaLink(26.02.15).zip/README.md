# VidaLink 🚑

Plataforma web para respuesta rápida a emergencias médicas mediante voluntarios cercanos.

## Tecnologías
- HTML, CSS, JavaScript
- Firebase Authentication
- Firestore
- Bootstrap

## Nota
El archivo `firebase-init.js` no está incluido por seguridad.
